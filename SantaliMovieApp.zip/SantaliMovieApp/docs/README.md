# Santali Movie — Android App

Yeh ek complete Android project hai (Kotlin + Jetpack Compose + Media3 ExoPlayer).

## 1. Project ki files
- `app/src/main/java/.../Movies.kt` — movies ki list (yahan content add karein)
- `app/src/main/java/.../MainActivity.kt` — UI, search, categories, player
- `app/src/main/AndroidManifest.xml` — app ki permissions aur settings
- `docs/PRIVACY_POLICY.md` — Play Store ke liye privacy policy

## 2. App kaise chalayein (test)
1. Android Studio download karein (developer.android.com/studio).
2. `File > Open` karke `SantaliMovieApp` folder select karein.
3. Gradle sync hone dein (pehli baar 5–10 minute lag sakte hain).
4. Phone ko USB debugging ke saath connect karein, ya emulator chalayein.
5. Run (▶) dabayein.

## 3. App ka icon aur naam
- Icon: Android Studio mein `File > New > Image Asset` se 512×512 icon banayein. Play Store ke liye 512×512 PNG alag se chahiye.
- Naam: `app/src/main/res/values/strings.xml` mein `app_name` badal sakte hain.

## 4. Play Store ke liye release banana
1. Signing key banayein:
   `keytool -genkey -v -keystore santali-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias santali`
   Yeh file aur password safe rakhein. Kho gayi to update kabhi nahi ho paayega.
2. Android Studio mein `Build > Generate Signed App Bundle / APK > Android App Bundle` chunein aur key select karein.
3. Output `.aab` file Play Console par upload hogi.

## 5. Play Console checklist (yeh sab zaroori hai)
- [ ] Google Play Developer account (ek baar $25 fee, identity verification ke saath)
- [ ] App ka naam, short description (80 characters tak), full description (4000 tak)
- [ ] App icon 512×512 PNG
- [ ] Feature graphic 1024×500 PNG/JPG
- [ ] Phone screenshots (kam se kam 2, 16:9 ya 9:16)
- [ ] Privacy policy ka public URL (docs/PRIVACY_POLICY.md ko GitHub Pages ya apni website par host karein)
- [ ] Data safety form (app koi data collect nahi karta to "No data collected" bharein, agar analytics add karein to update karein)
- [ ] Content rating questionnaire (IARC)
- [ ] Target audience aur content (age group chunein)
- [ ] Ads declaration (agar ads nahi hain to "No")
- [ ] App access (agar login ho to test credentials dein; abhi zaroori nahi)
- [ ] Target API level 35 ya uska latest (yeh project 35 par set hai)
- [ ] Countries/regions chunein
- [ ] Pricing: free ya paid

## 6. Sabse zaroori baat: content ke rights
Play Store copyrighted movies ko approve nahi karta jinke rights aapke paas nahi hain. Sirf woh movies daalein jo:
- aapki apni banayi hui hain, ya
- jinke liye aapke paas written license/permission hai, ya
- jo public domain mein hain.
Galat content se app reject ya band bhi ho sakta hai.

## 7. Aage ke features (jab zaroorat ho)
- Movie poster ki real image (Coil library)
- Login aur favorites (Firebase Auth)
- Movie ki video server se list (backend ya Firebase)
- Offline download
- Payment ya subscription (Google Play Billing)
