# Privacy Policy — Santali Movie

Last updated: [date daalein]

Santali Movie ("app") aapki privacy ka sammaan karti hai.

**1. Hum kya data collect karte hain:** Is app mein koi account, login, naam, email, phone number ya location collect nahi hota.

**2. Internet:** App movies stream karne ke liye internet use karta hai. Video server par request jaati hai, jisme aapka IP address aur device ki basic technical information ho sakti hai.

**3. Third-party services:** Agar aap baad mein analytics, ads ya crash reporting (jaise Firebase) add karte hain, to is policy ko update karna zaroori hai.

**4. Bachchon ki privacy:** Yah app bachchon ke liye jaan-boojhkar design nahi kiya gaya hai.

**5. Sampark:** Koi sawal ho to email karein: [aapka email yahan]

**6. Badlav:** Is policy mein badlav hone par app ke andar ya yahin update kiya jaayega.
