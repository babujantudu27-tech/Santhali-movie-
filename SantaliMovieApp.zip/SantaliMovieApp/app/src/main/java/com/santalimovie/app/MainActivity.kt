package com.santalimovie.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SantaliMovieApp() }
    }
}

@Composable
fun SantaliMovieApp() {
    var selected by remember { mutableStateOf<Movie?>(null) }
    var category by remember { mutableStateOf("All") }
    var query by remember { mutableStateOf("") }

    val categories = listOf("All") + allMovies.map { it.category }.distinct()
    val movies = allMovies.filter { m ->
        (category == "All" || m.category == category) &&
            (m.title.contains(query, ignoreCase = true) || m.desc.contains(query, ignoreCase = true))
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFFFF7A1A),
            background = Color(0xFF0F0F14),
            surface = Color(0xFF1C1C26)
        )
    ) {
        Surface(Modifier.fillMaxSize()) {
            val sel = selected
            if (sel == null) {
                Column(Modifier.fillMaxSize()) {
                    Text(
                        "🎬 Santali Movie",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFFF7A1A),
                        modifier = Modifier.padding(16.dp)
                    )
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        singleLine = true,
                        placeholder = { Text("Movie ka naam search karein") },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                        shape = RoundedCornerShape(24.dp)
                    )
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(12.dp)) {
                        categories.forEach { c ->
                            FilterChip(
                                selected = c == category,
                                onClick = { category = c },
                                label = { Text(c) },
                                modifier = Modifier.padding(end = 8.dp)
                            )
                        }
                    }
                    if (movies.isEmpty()) {
                        Text("Koi movie nahi mili 😔", modifier = Modifier.padding(24.dp))
                    }
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(160.dp),
                        contentPadding = PaddingValues(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(movies) { m -> MovieCard(m) { selected = m } }
                    }
                }
            } else {
                PlayerScreen(sel) { selected = null }
            }
        }
    }

    BackHandler(enabled = selected != null) { selected = null }
}

@Composable
fun MovieCard(movie: Movie, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp)
                .background(Brush.linearGradient(movie.colors)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                movie.title,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(12.dp)
            )
        }
        Column(Modifier.padding(10.dp)) {
            Text(movie.title, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(
                "${movie.year} • ${movie.category} • ${movie.lang}",
                fontSize = 12.sp,
                color = Color.Gray
            )
        }
    }
}

@Composable
fun PlayerScreen(movie: Movie, onBack: () -> Unit) {
    val context = LocalContext.current
    val player = remember(movie.url) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(movie.url))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) {
        onDispose { player.release() }
    }

    Column(Modifier.fillMaxSize()) {
        AndroidView(
            factory = { ctx -> PlayerView(ctx).apply { this.player = player } },
            modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f)
        )
        Column(Modifier.padding(16.dp)) {
            Text(movie.title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("${movie.year} • ${movie.category}", color = Color.Gray)
            Spacer(Modifier.height(8.dp))
            Text(movie.desc)
            Spacer(Modifier.height(16.dp))
            Button(onClick = onBack) { Text("Wapas jayein") }
        }
    }
}
