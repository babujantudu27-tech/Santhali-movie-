package com.santalimovie.app

import androidx.compose.ui.graphics.Color

data class Movie(
    val id: Int,
    val title: String,
    val year: Int,
    val category: String,
    val lang: String,
    val desc: String,
    val colors: List<Color>,
    val url: String
)

// Yahan apni movies add karein. url = aapki MP4 / HLS (.m3u8) ka direct link.
val allMovies = listOf(
    Movie(
        1, "Sample Movie 1", 2024, "Drama", "Santali",
        "Yeh sample movie hai. Apni asli Santali movie ki detail yahan likhein.",
        listOf(Color(0xFFFF7A1A), Color(0xFF7A2CFF)),
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
    ),
    Movie(
        2, "Sample Movie 2", 2023, "Comedy", "Santali",
        "Comedy movie ka sample description.",
        listOf(Color(0xFF00B894), Color(0xFF0984E3)),
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"
    ),
    Movie(
        3, "Sample Movie 3", 2025, "Action", "Santali",
        "Action movie ka sample description.",
        listOf(Color(0xFFD63031), Color(0xFFFDCB6E)),
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4"
    ),
    Movie(
        4, "Sample Movie 4", 2022, "Culture", "Santali",
        "Culture aur parampara par based sample movie.",
        listOf(Color(0xFF6C5CE7), Color(0xFF00CEC9)),
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4"
    )
)
